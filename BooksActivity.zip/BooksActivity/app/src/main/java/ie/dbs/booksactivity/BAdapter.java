package ie.dbs.booksactivity;

import android.os.StrictMode;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BAdapter extends RecyclerView.Adapter<BAdapter.ViewHolder> {

    private List<Object> books;

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView book_name;
        public TextView ISBN;
        public TextView volume;
        public TextView edition;
        public View layout;
        public ViewHolder(final View v){
            super(v);
            layout = v;
            book_name = (TextView) v.findViewById(R.id.book_name);
            ISBN = (TextView) v.findViewById(R.id.ISBN);
            volume = (TextView) v.findViewById(R.id.volume);
            edition = (TextView) v.findViewById(R.id.edition);
        }
    }

    @Override
    public BAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View bookView = inflater.inflate(R.layout.book, parent, false);
        ViewHolder book = new ViewHolder(bookView);
        return book;
    }

    public BAdapter(List<Object> dataset) {
        books = dataset;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        final Map book = (HashMap) books.get(position);
        holder.book_name.setText(book.get("ISBN") + "");
        holder.ISBN.setText(book.get("ISBN") + "");
        holder.edition.setText(book.get("Edition") + "");
        holder.volume.setText(book.get("Volume") + "");
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    @Override
    public int getItemCount() {
        return books.size();
    }
}
